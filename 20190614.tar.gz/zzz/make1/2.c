/* 2.c */
#include <stdio.h>
#include "a.h"
#include "b.h"

void function_two() {
printf("4-3 66 10627046 莊品毅\n");
}
